// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// //import './BusList.css';
// import logo from '../assets/cuet-logo.png';

// function BusList() {
//     const [buses, setBuses] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         axios.get('http://localhost:8080/api/buses/active')
//             .then(response => {
//                 setBuses(response.data);
//                 setLoading(false);
//             })
//             .catch(error => {
//                 console.error("Error fetching bus data:", error);
//                 setError(error);
//                 setLoading(false);
//             });
//     }, []);

//     if (loading) return <p>Loading...</p>;
//     if (error) return <p>There was an error loading the data.</p>;

//     return (
//         <div className="bus-list-page">
//             <header className="navbar">
//                 <img src={logo} alt="CUET logo" className="logo" />
//                 <h1>CUET Transport Management App</h1>
//             </header>
//             <h1>Bus List</h1>
//             <div className="bus-list">
//                 {buses.map(bus => (
//                     <div key={bus.id} className="bus-item">
//                         <h2>{bus.name}</h2>
//                         <p>Code: {bus.code}</p>
//                         <p>Total Seats: {bus.totalSeats}</p>
//                         <p>Occupied Seats: {bus.occupiedSeats}</p>
//                         <p>Status: {bus.busStatus}</p>
//                         <p>Direction: {bus.direction}</p>
//                     </div>
//                 ))}
//             </div>
//         </div>
//     );
// }

// export default BusList;
