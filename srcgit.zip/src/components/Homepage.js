import React from 'react';
import './Homepage.css';
import { Link } from 'react-router-dom';
  // Add this line to include the Navbar
//import '@fortawesome/fontawesome-free/css/all.min.css';


function Homepage() {
    return (
        <div className="homepage">
              {/* Add this line to include the Navbar */}
            
            

            <section className="main-section">

                <div className="column" id="mission">
                    <Link to="/mission">
                        <h3>Our Mission</h3>
                        <p>Tells about our motivation and next features.</p>
                    </Link>
                </div>
                <div className="column" id="buses">
                    <Link to="/buses">
                        <h3>About Buses</h3>
                        <p>CUET bus pictures come randomly with information.</p>
                    </Link>
                </div>
                <div className="column" id="notice">
                    <Link to="/notice">
                        <h3>Notice</h3>
                        <p>Links of recent notices.</p>
                    </Link>
                </div>

                <section className="hero">
                <div className="hero-content">
                    <Link to="/login">
                        <button className="login-button">Login / Register</button>
                    </Link>
                    <button className="know-button">Know More</button>
                    <button className="about-button">About Dev</button>
                </div>
            </section>


            </section>

            {/* <section className="hero">
                <div className="hero-content">
                    <Link to="/login">
                        <button className="login-button">Login / Register</button>
                    </Link>
                    <button className="know-button">Know More</button>
                    <button className="about-button">About Dev</button>
                </div>
            </section> */}

            
        </div>
    );
}

export default Homepage;
