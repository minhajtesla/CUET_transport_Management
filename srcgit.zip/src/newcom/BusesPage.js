import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './BusList.css';
import Navbar from '../components/Navbar';

//import Footer from '../components/Footer'; // Import the Footer component


function BusesPage() {
    const [buses, setBuses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:8080/api/buses')
            .then(response => {
                setBuses(response.data);
                setLoading(false);
            })
            .catch(error => {
                console.error("There was an error fetching the bus data!", error);
                setError(error);
                setLoading(false);
            });
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>There was an error loading the data.</p>;

    return (
        <div className="bus-list-page">
            <Navbar />
            
            <h1 className="title">           </h1>

            <div className="bus_box">
                <div className="bus-list">
                <h1 className="title">Bus List</h1>
            <p className="intro">Explore the available CUET buses and their respective routes and schedules.</p>
            
                    {buses.map((bus) => (
                        <div key={bus.id} className="bus-item">
                            <h2 className="bus-name">{bus.name}</h2>
                            <p className="bus-description">Code: {bus.code}</p>
                            <p className="bus-description">Total Seats: {bus.totalSeats}</p>
                            </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default BusesPage;
