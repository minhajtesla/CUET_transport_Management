import React from 'react';

function NoticePage() {
    return (
        <div>
            <h1>Notice</h1>
            <p>Latest notices and announcements.</p>
        </div>
    );
}

export default NoticePage;
